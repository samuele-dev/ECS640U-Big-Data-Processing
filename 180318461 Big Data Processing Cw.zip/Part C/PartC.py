from mrjob.job import MRJob, MRStep

class PartC(MRJob):
    # First Mapper
    def mapper(self, _, line):
        try:
            fields = line.split(',')
            if len(fields) == 9:
                miner = fields[2]
                size = int(fields[4])
                yield(miner, size)
        except:
            pass
    # First Reducer
    def reducer(self, miner, size):
        yield(miner, sum(size))
    
    # Second Mapper
    def mapperS(self, miner, size):
        try:
            yield(None, (miner, int(size)))
        except:
            pass
    # Second Reducer
    def reducerS(self, key, ms_values):
        sorted_miners = sorted(ms_values, reverse=True, key=lambda miner:miner[1])[:10]
        count = 0
        for miner in sorted_miners:
            count += 1
            yield(count, '{}-{}'.format(miner[0], miner[1]))
    
    def steps(self):
        return [MRStep(mapper=self.mapper, reducer=self.reducer),
        MRStep(mapper=self.mapperS, reducer=self.reducerS)]

if __name__ == '__main__':
    PartC.run()