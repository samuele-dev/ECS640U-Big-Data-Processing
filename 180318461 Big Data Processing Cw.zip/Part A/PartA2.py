from mrjob.job import MRJob
import time
# Transactions - dataset
class PartA2(MRJob):
    def mapper(self, _, line):
        try:
            fields = line.split(',')
            if len(fields) == 7:
                block_timestamp = int(fields[6])
                date = time.strftime("%m %y", time.gmtime(block_timestamp))
                values = int(fields[3])
                yield(date, (values, 1))
        except:
            pass
    def combiner(self, date, values):
        total = 0 # sum of all transactions
        num_of_transactions = 0 # how many transactions took place
        for value in values:
            total += value[0]
            num_of_transactions += value[1]
        yield(date, (total, num_of_transactions))

    def reducer(self, date, values):
        total = 0
        num_of_transactions = 0
        for value in values:
            total += value[0]
            num_of_transactions += value[1]
        yield(date, (total/num_of_transactions))
        
if __name__ == '__main__':
    PartA2.run()
