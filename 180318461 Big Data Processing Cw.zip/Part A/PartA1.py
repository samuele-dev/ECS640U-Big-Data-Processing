from mrjob.job import MRJob
import time
# Transactions - dataset
class PartA1(MRJob):
    def mapper(self, _, line):
        try:
            fields = line.split(',')
            if len(fields) == 7:
                block_timestamp = int(fields[6])
                date = time.strftime("%m %y", time.gmtime(block_timestamp))
                yield(date, 1)
        except:
            pass
    def combiner(self, date, value):
        yield(date, sum(value))
    def reducer(self, date, value):
        yield(date, sum(value))

if __name__ == '__main__':
    PartA1.run()
