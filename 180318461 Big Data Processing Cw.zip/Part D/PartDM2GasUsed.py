from mrjob.job import MRJob
import time

class PartDM2GasUsed(MRJob):
    # Use transactions dataset.
    def mapper(self, _, line):
        try:
            fields = line.split(',')
            if len(fields) == 7:
                block_timestamp = int(fields[6])
                date = time.strftime("%m %y", time.gmtime(block_timestamp))
                gas_used = float(fields[4])

                yield(date, (gas_used, 1))
        except:
            pass
    
    def combiner(self, date, values):
        total = 0
        gas_used_count = 0
        for value in values:
            total += value[0]
            gas_used_count += value[1]
        yield(date, (total, gas_used_count))

    def reducer(self, date, values):
        total = 0
        gas_used_count = 0
        for value in values:
            total += value[0]
            gas_used_count += value[1]
        yield(date, (total/gas_used_count))

if __name__ == '__main__':
    PartDM2GasUsed.run()
