from mrjob.job import MRJob
import time

class PartDM2GasPrice(MRJob):
    # Use transactions dataset. average gas price
    def mapper(self, _, line):
        try:
            fields = line.split(',')
            if len(fields) == 7:
                block_timestamp = int(fields[6])
                date = time.strftime("%m %y", time.gmtime(block_timestamp))
                gas_price = float(fields[5])

                yield(date, (gas_price, 1))
        except:
            pass
    
    def combiner(self, date, values):
        total = 0
        gas_price_count = 0
        for value in values:
            total += value[0]
            gas_price_count += value[1]
        yield(date, (total, gas_price_count))

    def reducer(self, date, values):
        total = 0
        gas_price_count = 0
        for value in values:
            total += value[0]
            gas_price_count += value[1]
        yield(date, (total/gas_price_count))

if __name__ == '__main__':
    PartDM2GasPrice.run()
