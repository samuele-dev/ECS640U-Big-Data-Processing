from mrjob.job import MRJob
# Transactions
class PartB1(MRJob):
    def mapper(self, _, line):
        try:
            fields = line.split(',')
            if len(fields) == 7:
                to_address = str(fields[2])
                value = int(fields[3])
                if not (to_address == "null" and value == 0):
                    yield(to_address, value)
        except:
            pass
    def combiner(self, to_address, value):
        yield(to_address, sum(value))
    def reducer(self, to_address, value):
        yield(to_address, sum(value))

if __name__ == '__main__':
    PartB1.run()
