from mrjob.job import MRJob

class PartB3(MRJob):
    def mapper(self, _, line):
        try:
            # Values from
            fields = line.split('\t')
            if len(fields) == 2:
                address = fields[0]
                value = int(fields[1])

                yield(None, (address, value))
        except:
            pass
    
    def reducer(self, key, av_values):
        sorted_addresses = sorted(av_values, reverse=True, key=lambda ad:ad[1])[:10]
        count = 0
        for address in sorted_addresses:
            count += 1
            yield(count, '{}-{}'.format(address[0], address[1]))

if __name__ == '__main__':
    PartB3.run()