from mrjob.job import MRJob

class PartB2(MRJob):
    # Works
    def mapper(self, _, line):
        try:
            # Transactions result pass.
            if(len(line.split('\t'))==2):
                fields = line.split('\t')
                join_key = fields[0].replace('\"','')
                join_value = fields[1]
                
                yield(join_key, (join_value, 1))
            # Contracts table
            elif(len(line.split(','))==5):
                fields = line.split(',')
                join_key = fields[0]
                
                # no values are passed through.
                yield(join_key, (None, 2))
        except:
            pass
    # Work on this.
    def reducer(self, address, values):
        total = 0
        status = False

        for value in values:
            if value[1] == 1:
                total += int(value[0])
            elif value[1] == 2:
                status = True
        if status != False and total !=0:
            yield(address, total)

if __name__ == '__main__':
    PartB2.run()